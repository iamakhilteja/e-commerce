interface City {
    value?: any;
    country?: any;
  }
  
  const cities: City[] = [
    { value: 'Mumbai', country: 'India' },
    { value: 'Delhi', country: 'India' },
    { value: 'Bangalore', country: 'India' },
    { value: 'Hyderabad', country: 'India' },
    { value: 'Chennai', country: 'India' },
    { value: 'Kolkata', country: 'India' },
    { value: 'Ahmedabad', country: 'India' },
    { value: 'Pune', country: 'India' },
    { value: 'Jaipur', country: 'India' },
    { value: 'Surat', country: 'India' },
    { value: 'Lucknow', country: 'India' },
    { value: 'Kanpur', country: 'India' },
    { value: 'Nagpur', country: 'India' },
    { value: 'Indore', country: 'India' },
    { value: 'Thane', country: 'India' },
    { value: 'Bhopal', country: 'India' },
    { value: 'Visakhapatnam', country: 'India' },
    { value: 'Patna', country: 'India' },
    { value: 'Vadodara', country: 'India' },
    { value: 'Ghaziabad', country: 'India' },
  ];
  
  export default cities;
  