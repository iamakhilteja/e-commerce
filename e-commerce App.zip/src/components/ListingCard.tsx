// src/pages/ListingPage.tsx
import React, { useState, useEffect, useMemo } from "react";
import {
  IonPage,
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonCard,
  IonCardHeader,
  IonCardContent,
  IonImg,
  IonCardTitle,
  IonCol,
  IonRow,
  IonBackButton,
  IonButtons,
  IonIcon,
  IonBadge,
} from "@ionic/react";
import axios from "axios";
import { useHistory } from "react-router";
import { arrowBackOutline, caretBack, star } from "ionicons/icons";
import ComHeader from "./Toolbar";
import "./ListingCard.css";
import WishlistButton from "./WishlistButton";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

export interface Product {
  id: number;
  title: string;
  description: string;
  price: number;
  image: string;
  rating: { rate: number; count: number };
  // Add other properties specific to a product
}

const ListingPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const history = useHistory();

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await fetch("https://fakestoreapi.com/products");
      const data = await response.json(); // Added parentheses here
      setProducts(data);
    } catch (error) {
      console.error("Error fetching products:", error);
    }
  };

  const handleProductClick = useMemo(
    () => (productId: number) => {
      history.push(`/products/${productId}`);
    },
    [history]
  );

  return (
    <IonPage>
      <IonHeader>
        <ComHeader />
      </IonHeader>
      <IonContent>
        <IonRow className="list-row">
          {products.map((product) => (
            <IonCol
              key={product.id}
              className="list-sec"
              size="6"
              sizeMd="4"
              sizeLg="2"
            >
              <IonCard className="list-card" key={product.id}
                  onClick={() => handleProductClick(product.id)}>
                <div className="wishicon">
                  <WishlistButton productId={product.id} />
                </div>
                <IonCardHeader
                  className="list-imgbox"
                >
                  <LazyLoadImage
                    src={product.image}
                    alt={product.title}
                    effect="blur" // Add a blur effect while loading
                    visibleByDefault // Make the image initially visible
                    className="list-img"
                  />
                </IonCardHeader>
                <IonCardContent className="list-cont">
                  <div className="list-title">
                    <IonLabel>{product.title}</IonLabel>
                  </div>
                  <div className="rating-div">
                    <span>
                      <IonBadge
                        className={`${
                          product.rating.rate < 4
                            ? product.rating.rate < 3
                              ? "red-badge"
                              : "yellow-badge"
                            : "green-badge"
                        }`}
                      >
                        <IonIcon icon={star} color="white" />
                        <span>{product.rating.rate}</span>
                      </IonBadge>
                    </span>
                    <span>({product.rating.count})</span>
                  </div>
                  <div className="list-price">
                    <h2 className="price-text">Rs. {product.price} </h2>
                  </div>
                </IonCardContent>
              </IonCard>
            </IonCol>
          ))}
        </IonRow>
      </IonContent>
    </IonPage>
  );
};

export default ListingPage;
