// src/App.tsx
import React, { useState } from 'react';
import { IonApp, IonRouterOutlet } from '@ionic/react';


const ListPage: React.FC = () => {
 

  // Replace this with your product data from the server or API
 ;

  return (
    <IonApp>
     
    </IonApp>
  );
};

export default ListPage;
